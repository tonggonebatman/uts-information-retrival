<?php
$host='localhost';
$user='root';
$pass='';
$database='utsinre';
$conn=mysqli_connect( $host,$user,$pass, $database);
?>